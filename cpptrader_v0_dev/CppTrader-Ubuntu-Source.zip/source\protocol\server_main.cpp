/*!
    \file server_main.cpp
    \brief Protocol server entry point
    \author CppTrader Team
    \date 18.05.2026
    \copyright MIT License
*/

#include "trader/protocol/server.h"
#include "trader/protocol/tcp_backend.h"
#include "trader/protocol/request_handler.h"
#include "trader/matching/market_manager.h"

#include <asio.hpp>

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <string>
#include <thread>

using namespace CppTrader;
using namespace CppTrader::Protocol;

void PrintUsage(const char* program)
{
    std::cout << "Usage: " << program << " [options]" << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  --port <port>      TCP listen port (default: 8080)" << std::endl;
    std::cout << "  --help             Show this help message" << std::endl;
}

int main(int argc, char** argv)
{
    uint16_t port = 8080;

    // Parse command line arguments
    for (int i = 1; i < argc; ++i)
    {
        std::string arg(argv[i]);

        if (arg == "--port" && i + 1 < argc)
        {
            port = static_cast<uint16_t>(std::atoi(argv[++i]));
        }
        else if (arg == "--help" || arg == "-h")
        {
            PrintUsage(argv[0]);
            return 0;
        }
        else
        {
            std::cerr << "Unknown option: " << arg << std::endl;
            PrintUsage(argv[0]);
            return 1;
        }
    }

    // Create asio io_context
    asio::io_context io_context;

    // Create network backend (TCP only)
    std::unique_ptr<INetworkBackend> backend;
    std::cout << "Using TCP backend on port " << port << std::endl;
    backend = std::make_unique<TcpBackend>(io_context, port);

    // Create market manager and request handler
    Matching::MarketManager market;

    // Create protocol server
    auto server = std::make_unique<ProtocolServer>(std::move(backend), market);

    // Create request handler (this also registers itself as MarketHandler)
    RequestHandler request_handler(*server, market);
    request_handler.RegisterHandlers();

    // Initialize server
    if (!server->init())
    {
        std::cerr << "Failed to initialize protocol server" << std::endl;
        return 1;
    }

    std::cout << "Protocol server started. Press Ctrl+C to stop." << std::endl;

    // Main event loop
    while (true)
    {
        server->poll();

        // Run asio handlers for timer-based operations
        io_context.poll();

        // Small yield to prevent busy-waiting
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    return 0;
}
