/*!
    \file server.h
    \brief Protocol server main class
    \author CppTrader Team
    \date 18.05.2026
    \copyright MIT License
*/

#ifndef CPPTRADER_PROTOCOL_SERVER_H
#define CPPTRADER_PROTOCOL_SERVER_H

#include "network_backend.h"
#include "protocol.h"
#include "message.h"

#include "trader/matching/market_manager.h"

#include <cstdint>
#include <cstddef>
#include <functional>
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace CppTrader {
namespace Protocol {

//! Protocol server main class
/*!
    The ProtocolServer manages the network backend, routes incoming requests
    to appropriate handlers based on msg_type, manages per-connection subscription
    state (symbol_id filtering), and broadcasts market events to subscribed clients.
*/
class ProtocolServer
{
public:
    //! Request handler function type
    using RequestHandler = std::function<void(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len)>;

    //! Constructor
    /*!
        \param backend - Network backend instance (TCP or DPDK)
        \param market - Market manager reference
    */
    ProtocolServer(std::unique_ptr<INetworkBackend> backend, CppTrader::Matching::MarketManager& market);
    ~ProtocolServer();

    ProtocolServer(const ProtocolServer&) = delete;
    ProtocolServer(ProtocolServer&&) = delete;
    ProtocolServer& operator=(const ProtocolServer&) = delete;
    ProtocolServer& operator=(ProtocolServer&&) = delete;

    //! Initialize the server
    bool init();

    //! Run one iteration of the event loop
    void poll();

    //! Register a handler for a specific message type
    /*!
        \param msg_type - Message type to handle
        \param handler - Handler function
    */
    void RegisterHandler(MsgType msg_type, const RequestHandler& handler);

    //! Send a response to a specific connection
    /*!
        \param conn_id - Connection identifier
        \param header - Message header
        \param body - Message body data
        \param body_len - Body length
    */
    void SendResponse(uint16_t conn_id, const MsgHeader& header, const void* body, size_t body_len);

    //! Send a response to a specific connection (header-only)
    /*!
        \param conn_id - Connection identifier
        \param header - Message header
    */
    void SendResponse(uint16_t conn_id, const MsgHeader& header);

    //! Broadcast a message to all connected clients
    /*!
        \param header - Message header
        \param body - Message body data
        \param body_len - Body length
    */
    void Broadcast(const MsgHeader& header, const void* body, size_t body_len);

    //! Broadcast a message to clients subscribed to a specific symbol
    /*!
        \param symbol_id - Symbol identifier to filter subscribers
        \param header - Message header
        \param body - Message body data
        \param body_len - Body length
    */
    void BroadcastToSymbol(uint32_t symbol_id, const MsgHeader& header, const void* body, size_t body_len);

    //! Subscribe a connection to order book updates for a symbol
    /*!
        \param conn_id - Connection identifier
        \param symbol_id - Symbol identifier
    */
    void SubscribeOrderBook(uint16_t conn_id, uint32_t symbol_id);

    //! Subscribe a connection to order updates for a symbol
    /*!
        \param conn_id - Connection identifier
        \param symbol_id - Symbol identifier
    */
    void SubscribeOrders(uint16_t conn_id, uint32_t symbol_id);

    //! Unsubscribe a connection from order book updates
    /*!
        \param conn_id - Connection identifier
        \param symbol_id - Symbol identifier
    */
    void UnsubscribeOrderBook(uint16_t conn_id, uint32_t symbol_id);

    //! Unsubscribe a connection from order updates
    /*!
        \param conn_id - Connection identifier
        \param symbol_id - Symbol identifier
    */
    void UnsubscribeOrders(uint16_t conn_id, uint32_t symbol_id);

    //! Remove all subscriptions for a connection (called on disconnect)
    /*!
        \param conn_id - Connection identifier
    */
    void RemoveConnection(uint16_t conn_id);

    //! Get the network backend
    INetworkBackend* Backend() const noexcept { return _backend.get(); }

    //! Get the market manager
    CppTrader::Matching::MarketManager& Market() const noexcept { return _market; }

private:
    std::unique_ptr<INetworkBackend> _backend;
    CppTrader::Matching::MarketManager& _market;

    // Message type -> handler mapping
    std::unordered_map<MsgType, RequestHandler> _handlers;

    // Subscription state: conn_id -> set of symbol_ids
    std::unordered_map<uint16_t, std::unordered_set<uint32_t>> _order_book_subscriptions;
    std::unordered_map<uint16_t, std::unordered_set<uint32_t>> _order_subscriptions;

    // Internal message dispatcher
    void OnMessage(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    void OnConnect(uint16_t conn_id);
    void OnDisconnect(uint16_t conn_id);
};

} // namespace Protocol
} // namespace CppTrader

#endif // CPPTRADER_PROTOCOL_SERVER_H
