/*!
    \file server.cpp
    \brief Protocol server implementation
    \author CppTrader Team
    \date 18.05.2026
    \copyright MIT License
*/

#include "trader/protocol/server.h"
#include "trader/protocol/tcp_backend.h"

#include <cstring>
#include <iostream>

namespace CppTrader {
namespace Protocol {

ProtocolServer::ProtocolServer(std::unique_ptr<INetworkBackend> backend, CppTrader::Matching::MarketManager& market)
    : _backend(std::move(backend))
    , _market(market)
{
}

ProtocolServer::~ProtocolServer()
{
}

bool ProtocolServer::init()
{
    if (!_backend)
    {
        std::cerr << "ProtocolServer::init() failed: no backend" << std::endl;
        return false;
    }

    // Set up backend callbacks
    if (auto* tcp = dynamic_cast<TcpBackend*>(_backend.get()))
    {
        tcp->SetMessageHandler([this](uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len)
        {
            OnMessage(conn_id, header, body, body_len);
        });
        tcp->SetConnectHandler([this](uint16_t conn_id)
        {
            OnConnect(conn_id);
        });
        tcp->SetDisconnectHandler([this](uint16_t conn_id)
        {
            OnDisconnect(conn_id);
        });
    }

    return _backend->init();
}

void ProtocolServer::poll()
{
    if (_backend)
    {
        _backend->poll();
    }
}

void ProtocolServer::RegisterHandler(MsgType msg_type, const RequestHandler& handler)
{
    _handlers[msg_type] = handler;
}

void ProtocolServer::SendResponse(uint16_t conn_id, const MsgHeader& header, const void* body, size_t body_len)
{
    if (!_backend)
        return;

    // Build complete frame: header + body
    std::vector<uint8_t> frame(sizeof(MsgHeader) + body_len);
    std::memcpy(frame.data(), &header, sizeof(MsgHeader));
    if (body_len > 0 && body != nullptr)
    {
        std::memcpy(frame.data() + sizeof(MsgHeader), body, body_len);
    }

    _backend->send(conn_id, frame.data(), frame.size());
}

void ProtocolServer::SendResponse(uint16_t conn_id, const MsgHeader& header)
{
    if (!_backend)
        return;

    _backend->send(conn_id, &header, sizeof(MsgHeader));
}

void ProtocolServer::Broadcast(const MsgHeader& header, const void* body, size_t body_len)
{
    if (!_backend)
        return;

    std::vector<uint8_t> frame(sizeof(MsgHeader) + body_len);
    std::memcpy(frame.data(), &header, sizeof(MsgHeader));
    if (body_len > 0 && body != nullptr)
    {
        std::memcpy(frame.data() + sizeof(MsgHeader), body, body_len);
    }

    _backend->broadcast(frame.data(), frame.size());
}

void ProtocolServer::BroadcastToSymbol(uint32_t symbol_id, const MsgHeader& header, const void* body, size_t body_len)
{
    if (!_backend)
        return;

    std::vector<uint8_t> frame(sizeof(MsgHeader) + body_len);
    std::memcpy(frame.data(), &header, sizeof(MsgHeader));
    if (body_len > 0 && body != nullptr)
    {
        std::memcpy(frame.data() + sizeof(MsgHeader), body, body_len);
    }

    // Send to order book subscribers
    for (const auto& [conn_id, symbols] : _order_book_subscriptions)
    {
        if (symbols.find(symbol_id) != symbols.end())
        {
            _backend->send(conn_id, frame.data(), frame.size());
        }
    }

    // Send to order subscribers
    for (const auto& [conn_id, symbols] : _order_subscriptions)
    {
        if (symbols.find(symbol_id) != symbols.end())
        {
            _backend->send(conn_id, frame.data(), frame.size());
        }
    }
}

void ProtocolServer::SubscribeOrderBook(uint16_t conn_id, uint32_t symbol_id)
{
    _order_book_subscriptions[conn_id].insert(symbol_id);
}

void ProtocolServer::SubscribeOrders(uint16_t conn_id, uint32_t symbol_id)
{
    _order_subscriptions[conn_id].insert(symbol_id);
}

void ProtocolServer::UnsubscribeOrderBook(uint16_t conn_id, uint32_t symbol_id)
{
    auto it = _order_book_subscriptions.find(conn_id);
    if (it != _order_book_subscriptions.end())
    {
        it->second.erase(symbol_id);
        if (it->second.empty())
        {
            _order_book_subscriptions.erase(it);
        }
    }
}

void ProtocolServer::UnsubscribeOrders(uint16_t conn_id, uint32_t symbol_id)
{
    auto it = _order_subscriptions.find(conn_id);
    if (it != _order_subscriptions.end())
    {
        it->second.erase(symbol_id);
        if (it->second.empty())
        {
            _order_subscriptions.erase(it);
        }
    }
}

void ProtocolServer::RemoveConnection(uint16_t conn_id)
{
    _order_book_subscriptions.erase(conn_id);
    _order_subscriptions.erase(conn_id);
}

void ProtocolServer::OnMessage(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len)
{
    auto it = _handlers.find(header.Type);
    if (it != _handlers.end())
    {
        it->second(conn_id, header, body, body_len);
    }
    else
    {
        std::cerr << "ProtocolServer: unhandled message type " << static_cast<int>(header.Type) << std::endl;
    }
}

void ProtocolServer::OnConnect(uint16_t conn_id)
{
    (void)conn_id;
}

void ProtocolServer::OnDisconnect(uint16_t conn_id)
{
    RemoveConnection(conn_id);
}

} // namespace Protocol
} // namespace CppTrader
