/*!
    \file request_handler.h
    \brief Protocol request handler
    \author CppTrader Team
    \date 18.05.2026
    \copyright MIT License
*/

#ifndef CPPTRADER_PROTOCOL_REQUEST_HANDLER_H
#define CPPTRADER_PROTOCOL_REQUEST_HANDLER_H

#include "server.h"
#include "protocol.h"
#include "message.h"

#include "trader/matching/market_handler.h"
#include "trader/matching/market_manager.h"
#include "trader/matching/symbol.h"
#include "trader/matching/order.h"
#include "trader/matching/order_book.h"
#include "trader/matching/level.h"

#include <cstdint>
#include <cstddef>

namespace CppTrader {
namespace Protocol {

//! Protocol request handler
/*!
    This class implements Matching::MarketHandler to receive all market events
    from MarketManager and converts them to protocol push messages.
    It also handles all incoming request types and dispatches them to MarketManager.
*/
class RequestHandler : public CppTrader::Matching::MarketHandler
{
public:
    //! Constructor
    /*!
        \param server - Protocol server reference for sending responses and broadcasts
        \param market - Market manager reference
    */
    RequestHandler(ProtocolServer& server, CppTrader::Matching::MarketManager& market);
    ~RequestHandler() override = default;

    RequestHandler(const RequestHandler&) = delete;
    RequestHandler(RequestHandler&&) = delete;
    RequestHandler& operator=(const RequestHandler&) = delete;
    RequestHandler& operator=(RequestHandler&&) = delete;

    //! Initialize and register all handlers with the protocol server
    void RegisterHandlers();

    // MarketHandler callbacks - Symbol events
protected:
    void onAddSymbol(const CppTrader::Matching::Symbol& symbol) override;
    void onDeleteSymbol(const CppTrader::Matching::Symbol& symbol) override;

    // MarketHandler callbacks - Order book events
    void onAddOrderBook(const CppTrader::Matching::OrderBook& order_book) override;
    void onUpdateOrderBook(const CppTrader::Matching::OrderBook& order_book, bool top) override;
    void onDeleteOrderBook(const CppTrader::Matching::OrderBook& order_book) override;

    // MarketHandler callbacks - Price level events
    void onAddLevel(const CppTrader::Matching::OrderBook& order_book, const CppTrader::Matching::Level& level, bool top) override;
    void onUpdateLevel(const CppTrader::Matching::OrderBook& order_book, const CppTrader::Matching::Level& level, bool top) override;
    void onDeleteLevel(const CppTrader::Matching::OrderBook& order_book, const CppTrader::Matching::Level& level, bool top) override;

    // MarketHandler callbacks - Order events
    void onAddOrder(const CppTrader::Matching::Order& order) override;
    void onUpdateOrder(const CppTrader::Matching::Order& order) override;
    void onDeleteOrder(const CppTrader::Matching::Order& order) override;

    // MarketHandler callbacks - Order execution events
    void onExecuteOrder(const CppTrader::Matching::Order& order, uint64_t price, uint64_t quantity) override;

    // Request handlers
public:
    //! Handle AddSymbol request
    void HandleAddSymbol(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle DeleteSymbol request
    void HandleDeleteSymbol(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle GetSymbol request
    void HandleGetSymbol(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

    //! Handle AddOrderBook request
    void HandleAddOrderBook(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle DeleteOrderBook request
    void HandleDeleteOrderBook(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle GetOrderBook request
    void HandleGetOrderBook(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

    //! Handle AddOrder request
    void HandleAddOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle ReduceOrder request
    void HandleReduceOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle ModifyOrder request
    void HandleModifyOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle MitigateOrder request
    void HandleMitigateOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle ReplaceOrder request
    void HandleReplaceOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle DeleteOrder request
    void HandleDeleteOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle ExecuteOrder request
    void HandleExecuteOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle GetOrder request
    void HandleGetOrder(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

    //! Handle EnableMatching request
    void HandleEnableMatching(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle DisableMatching request
    void HandleDisableMatching(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

    //! Handle SubscribeOrderBook request
    void HandleSubscribeOrderBook(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);
    //! Handle SubscribeOrders request
    void HandleSubscribeOrders(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

    //! Handle Heartbeat request
    void HandleHeartbeat(uint16_t conn_id, const MsgHeader& header, const uint8_t* body, size_t body_len);

private:
    ProtocolServer& _server;
    CppTrader::Matching::MarketManager& _market;

    // Helper methods
    static OrderProto ConvertOrder(const CppTrader::Matching::Order& order);
    static SymbolProto ConvertSymbol(const CppTrader::Matching::Symbol& symbol);
    static LevelProto ConvertLevel(const CppTrader::Matching::Level& level);
    static CppTrader::Matching::Order ConvertOrderProto(const OrderProto& proto);
    static CppTrader::Matching::Symbol ConvertSymbolProto(const SymbolProto& proto);
    static CppTrader::Matching::OrderType ConvertOrderType(OrderType type);
    static CppTrader::Matching::OrderSide ConvertOrderSide(OrderSide side);
    static CppTrader::Matching::OrderTimeInForce ConvertOrderTimeInForce(OrderTimeInForce tif);
    static ErrorCode ConvertMatchingError(CppTrader::Matching::ErrorCode error);
};

} // namespace Protocol
} // namespace CppTrader

#endif // CPPTRADER_PROTOCOL_REQUEST_HANDLER_H
